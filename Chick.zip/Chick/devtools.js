// Can use
// chrome.devtools.*
// chrome.extension.*

// Create a tab in the devtools area
chrome.devtools.panels.create("Magpie Hatchery", 
  "images/icon-brand_prominence-noshadow.png", 
  "panel.html", 
  function(panel) {

  });
